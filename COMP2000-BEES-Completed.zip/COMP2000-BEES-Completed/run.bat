@echo off
setlocal
cd /d "%~dp0"
call build.bat
if errorlevel 1 exit /b 1
java -cp "build\classes;lib\jaylib-6.0.1-0.jar" App %*
exit /b %errorlevel%
