import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import Components.Vec3;
import org.bytedeco.javacpp.PointerScope;
import static com.raylib.Raylib.*;

/** Native desktop view. Simulation classes never allocate graphics resources. */
public final class SceneRenderer {
    private static final int TOP = 92;
    private static final int BOTTOM = 110;
    private static final int SIDEBAR = 310;
    private static final Color INK = color(29, 53, 44);
    private static final Color MUTED = color(106, 122, 105);
    private static final Color PAPER = color(246, 246, 232);
    private static final Color WHITE = color(255, 255, 249);
    private static final Color GOLD = color(244, 193, 75);
    private static final Color RED = color(199, 69, 57);
    private static final Color SKY = color(211, 230, 218);
    private static final Color BLUE = color(88, 145, 167);
    private final ObjectPicker<SceneObject> picker = new ObjectPicker<>();
    private Camera3D camera;
    private RenderTexture sceneTexture;
    private int sceneWidth;
    private int sceneHeight;
    private double yaw = 0.45;
    private double pitch = 0.66;
    private double distance = 33;
    private SceneObject selected;
    private boolean paths;
    private boolean captureRequested;
    private String message = "Click a bee, flower, or hive to inspect it.";
    private double messageTimer = 8;

    private enum Action { WORKER, FLOWERS, WASP, VISITOR, PAUSE, SPEED, THREATS, RESET }

    @SuppressWarnings("try") // PointerScope releases native temporaries through close().
    public void run(Simulation simulation, int frameLimit, Path screenshot) throws IOException {
        if (screenshot != null && screenshot.getParent() != null) Files.createDirectories(screenshot.getParent());
        SetConfigFlags(FLAG_WINDOW_RESIZABLE | FLAG_MSAA_4X_HINT);
        InitWindow(1280, 800, "Bee Simulator");
        try {
            if (!IsWindowReady()) throw new IllegalStateException("A desktop window could not be opened.");
            SetWindowMinSize(1100, 720);
            SetTargetFPS(60);
            camera = new Camera3D().target(vector(new Vec3(0, 0.5, 0)))
                    .up(vector(new Vec3(0, 1, 0))).fovy(45).projection(CAMERA_PERSPECTIVE);
            selected = simulation.getHive();
            try (SceneAssets assets = new SceneAssets()) {
                int frame = 0;
                while (!WindowShouldClose() && (frameLimit == 0 || frame < frameLimit)) {
                    resizeScene();
                    // Release temporary native vectors/rectangles at the end of each frame.
                    try (PointerScope scope = new PointerScope()) {
                        double deltaTime = Math.min(GetFrameTime(), 0.1);
                        handleInput(simulation, deltaTime);
                        simulation.advance(deltaTime);
                        if (selected != null && (!selected.isActive()
                                || !simulation.getSceneObjects().contains(selected))) selected = null;
                        drawScene(simulation, assets);
                        BeginDrawing();
                        ClearBackground(PAPER);
                        DrawTextureRec(sceneTexture.texture(),
                                rectangle(0, 0, sceneWidth, -sceneHeight),
                                new Vector2().x(0).y(TOP), WHITE);
                        drawInterface(simulation);
                        EndDrawing();
                        messageTimer = Math.max(0, messageTimer - deltaTime);
                        if (captureRequested) {
                            captureRequested = false;
                            Path capture = Path.of("screenshots", "bee-simulator.png").toAbsolutePath();
                            Files.createDirectories(capture.getParent());
                            saveScreenshot(capture);
                            notifyUser("Screenshot saved to screenshots/bee-simulator.png");
                        }
                        if (screenshot != null && frameLimit > 0 && frame + 1 == frameLimit) {
                            saveScreenshot(screenshot);
                        }
                    }
                    frame++;
                }
                if (screenshot != null && frameLimit == 0) saveScreenshot(screenshot);
                System.out.println("FINAL " + simulation.summary());
            }
        } finally {
            if (sceneTexture != null) { UnloadRenderTexture(sceneTexture); sceneTexture.close(); }
            if (camera != null) camera.close();
            CloseWindow();
        }
    }

    private void resizeScene() {
        int width = GetScreenWidth() - SIDEBAR;
        int height = GetScreenHeight() - TOP - BOTTOM;
        if (width == sceneWidth && height == sceneHeight) return;
        if (sceneTexture != null) { UnloadRenderTexture(sceneTexture); sceneTexture.close(); }
        sceneWidth = width;
        sceneHeight = height;
        sceneTexture = LoadRenderTexture(width, height);
        if (!IsRenderTextureValid(sceneTexture)) throw new IllegalStateException("Cannot create the scene framebuffer.");
    }

    private void handleInput(Simulation simulation, double deltaTime) {
        if (IsKeyPressed(KEY_F12)) captureRequested = true;
        int[] keys = {KEY_B, KEY_F, KEY_W, KEY_E, KEY_SPACE, KEY_X, KEY_T, KEY_R};
        Action[] actions = Action.values();
        for (int i = 0; i < actions.length; i++) {
            if (IsKeyPressed(keys[i])) perform(actions[i], simulation);
        }
        if (IsKeyPressed(KEY_G)) paths = !paths;
        if (IsKeyPressed(KEY_H)) select(simulation.getHive());
        if (IsKeyPressed(KEY_Q)) {
            select(simulation.getHive().getBees().stream()
                    .filter(bee -> bee instanceof BeeQueen && bee.isActive()).findFirst().orElse(null));
        }
        if (IsKeyPressed(KEY_TAB)) {
            List<SceneObject> objects = simulation.getSceneObjects().stream().filter(SceneObject::isActive).toList();
            int index = objects.indexOf(selected);
            if (!objects.isEmpty()) select(objects.get((index + 1) % objects.size()));
        }
        if (IsKeyPressed(KEY_HOME)) { yaw = 0.45; pitch = 0.66; distance = 33; }
        if (IsKeyDown(KEY_LEFT)) yaw -= deltaTime;
        if (IsKeyDown(KEY_RIGHT)) yaw += deltaTime;
        if (IsKeyDown(KEY_UP)) distance -= 12 * deltaTime;
        if (IsKeyDown(KEY_DOWN)) distance += 12 * deltaTime;
        if (IsKeyDown(KEY_PAGE_UP)) pitch += deltaTime * 0.5;
        if (IsKeyDown(KEY_PAGE_DOWN)) pitch -= deltaTime * 0.5;
        boolean overScene = GetMouseX() < sceneWidth && GetMouseY() >= TOP && GetMouseY() < TOP + sceneHeight;
        if (overScene) {
            distance -= GetMouseWheelMove() * 1.5;
            if (IsMouseButtonDown(MOUSE_BUTTON_RIGHT)) {
                Vector2 delta = GetMouseDelta();
                yaw -= delta.x() * 0.005;
                pitch += delta.y() * 0.003;
            }
        }
        distance = Math.max(8, Math.min(45, distance));
        pitch = Math.max(0.22, Math.min(1.25, pitch));
        camera._position(vector(new Vec3(distance * Math.cos(pitch) * Math.sin(yaw),
                0.5 + distance * Math.sin(pitch), distance * Math.cos(pitch) * Math.cos(yaw))));

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
            for (int i = 0; i < actions.length; i++) {
                if (CheckCollisionPointRec(GetMousePosition(), buttonBounds(i))) {
                    perform(actions[i], simulation);
                    return;
                }
            }
            if (overScene) {
                Vector2 point = new Vector2().x(GetMouseX()).y(GetMouseY() - TOP);
                Ray ray = GetScreenToWorldRayEx(point, camera, sceneWidth, sceneHeight);
                select(picker.pick(simulation.getSceneObjects(), coordinates(ray._position()),
                        coordinates(ray.direction())).orElse(null));
            }
        }
    }

    private void perform(Action action, Simulation simulation) {
        switch (action) {
            case WORKER -> {
                Bee bee = simulation.getHive().addBee(BeeFactory.Kind.WORKER);
                if (bee == null) notifyUser("The hive has reached its population limit.");
                else { select(bee); notifyUser("Added " + bee.getName() + "."); }
            }
            case FLOWERS -> notifyUser("Added " + simulation.getField().addFlowers(10) + " flowers.");
            case WASP, VISITOR -> {
                Enemy enemy = action == Action.WASP ? simulation.spawnWasp() : simulation.spawnExterminator();
                if (enemy == null) notifyUser("There are already 12 visitors in the meadow.");
                else { select(enemy); notifyUser(enemy.getName() + " entered the meadow."); }
            }
            case PAUSE -> { simulation.togglePause(); notifyUser(simulation.isPaused() ? "Simulation paused." : "Simulation resumed."); }
            case SPEED -> { simulation.cycleSpeed(); notifyUser("Simulation speed: " + simulation.getSpeed() + "x."); }
            case THREATS -> { simulation.toggleAutoThreats(); notifyUser(simulation.hasAutoThreats() ? "Automatic threats enabled." : "Automatic threats disabled."); }
            case RESET -> { simulation.reset(); selected = simulation.getHive(); notifyUser("Meadow reset."); }
        }
        System.out.println("ACTION " + action + " " + simulation.summary());
    }

    private void select(SceneObject object) {
        selected = object;
        System.out.println("SELECT " + (object == null ? "none" : object.getType() + " / " + object.getName()));
    }

    private void notifyUser(String text) {
        message = text;
        messageTimer = 5;
    }

    private void drawScene(Simulation simulation, SceneAssets assets) {
        BeginTextureMode(sceneTexture);
        ClearBackground(SKY);
        BeginMode3D(camera);
        DrawModel(assets.tree(), vector(Vec3.ZERO), 1, WHITE);
        for (Flower flower : simulation.getField().getFlowers()) {
            if (flower.isActive()) DrawBillboard(camera, assets.flower(), vector(flower.getPosition()), 1, WHITE);
        }
        for (Larvae larva : simulation.getHive().getLarvae()) {
            DrawSphereEx(vector(larva.getPosition()), 0.17f, 6, 8, PAPER);
        }
        for (Bee bee : simulation.getHive().getBees()) {
            if (!bee.isActive()) continue;
            boolean queen = bee instanceof BeeQueen;
            DrawBillboard(camera, assets.bee(), vector(bee.getPosition()), queen ? 0.85f : 0.6f, WHITE);
            if (queen) {
                DrawSphereEx(vector(bee.getPosition().add(0, 0.5, 0)), 0.09f, 5, 6, GOLD);
            }
            if (paths && bee instanceof BeeWorker worker && worker.getTarget() != null) {
                DrawLine3D(vector(worker.getPosition()), vector(worker.getTarget().getPosition()), GOLD);
            }
        }
        for (Enemy enemy : simulation.getEnemies()) {
            Vec3 p = enemy.getPosition();
            if (enemy instanceof Wasp) {
                DrawSphereEx(vector(p), 0.3f, 8, 8, RED);
                DrawSphereEx(vector(p.add(0.18, 0, 0.12)), 0.18f, 6, 6, INK);
                DrawSphereEx(vector(p.add(-0.2, 0.16, 0)), 0.17f, 6, 6, WHITE);
                DrawSphereEx(vector(p.add(0.2, 0.16, 0)), 0.17f, 6, 6, WHITE);
            } else if (enemy instanceof Exterminator visitor) {
                DrawCube(vector(p), 0.5f, 0.9f, 0.4f, BLUE);
                DrawSphereEx(vector(p.add(0, 0.65, 0)), 0.23f, 8, 8, GOLD);
                DrawCube(vector(p.add(-0.16, -0.55, 0)), 0.17f, 0.45f, 0.2f, INK);
                DrawCube(vector(p.add(0.16, -0.55, 0)), 0.17f, 0.45f, 0.2f, INK);
                if (visitor.isSpraying()) {
                    DrawCircle3D(vector(new Vec3(p.x(), 0.06, p.z())),
                            (float) Exterminator.SPRAY_RADIUS, vector(new Vec3(1, 0, 0)), 90, RED);
                }
            }
        }
        if (selected != null) {
            Vec3 half = selected.getCollider().halfSize();
            DrawCubeWires(vector(selected.getPosition()), (float) (half.x() * 2),
                    (float) (half.y() * 2), (float) (half.z() * 2), GOLD);
        }
        EndMode3D();
        DrawText("THE MEADOW", 22, 18, 16, INK);
        DrawText("Right-drag to orbit  /  Scroll to zoom", 22, 42, 16, MUTED);
        if (simulation.isPaused()) {
            DrawRectangleRounded(rectangle(sceneWidth / 2 - 65, 20, 130, 36), 0.3f, 6, INK);
            DrawText("PAUSED", sceneWidth / 2 - 42, 30, 18, GOLD);
        }
        if (simulation.getHive().livingCount() == 0 && simulation.getHive().getLarvae().isEmpty()) {
            DrawRectangleRounded(rectangle(22, 78, 430, 62), 0.15f, 6, WHITE);
            DrawText("The colony is empty.", 36, 88, 20, RED);
            DrawText("Reset [R] to start a new colony.", 36, 114, 17, INK);
        }
        legend();
        EndTextureMode();
    }

    private void legend() {
        String[] names = {"Worker", "Queen", "Larva", "Wasp", "Exterminator"};
        Color[] colors = {GOLD, GOLD, PAPER, RED, BLUE};
        int x = 24;
        for (int i = 0; i < names.length; i++) {
            DrawCircle(x, sceneHeight - 22, 5, colors[i]);
            DrawText(names[i], x + 12, sceneHeight - 30, 16, INK);
            x += MeasureText(names[i], 16) + 38;
        }
    }

    private void drawInterface(Simulation simulation) {
        int width = GetScreenWidth();
        int height = GetScreenHeight();
        Hive hive = simulation.getHive();
        DrawRectangle(0, 0, width, TOP, INK);
        DrawCircle(36, 33, 11, GOLD);
        DrawText("BEE SIMULATOR", 59, 20, 27, PAPER);
        DrawText("A living meadow", 60, 54, 16, color(188, 207, 184));
        stat(390, "HONEY", String.format(Locale.ROOT, "%.0f", hive.getHoney()));
        stat(530, "WORKERS", Long.toString(hive.getWorkerCount()));
        stat(670, "LARVAE", Integer.toString(hive.getLarvae().size()));
        stat(800, "THREATS", Integer.toString(simulation.getEnemies().size()));
        DrawText(String.format(Locale.ROOT, "%02d:%02d", (int) simulation.getElapsed() / 60,
                (int) simulation.getElapsed() % 60), width - 130, 22, 25, GOLD);
        DrawText(simulation.getSpeed() + "x  |  " + GetFPS() + " fps", width - 130, 55, 16, PAPER);

        int panelX = width - SIDEBAR;
        DrawRectangle(panelX, TOP, SIDEBAR, height - TOP - BOTTOM, PAPER);
        DrawText("OBJECT INSPECTOR", panelX + 22, TOP + 20, 16, MUTED);
        DrawRectangle(panelX + 20, TOP + 49, SIDEBAR - 42, 2, GOLD);
        if (selected == null) {
            DrawText("Explore the meadow", panelX + 22, TOP + 70, 20, INK);
            DrawText("Click an object to see its", panelX + 22, TOP + 110, 17, MUTED);
            DrawText("health, resources and activity.", panelX + 22, TOP + 134, 17, MUTED);
            DrawText("H: inspect hive", panelX + 22, TOP + 187, 17, INK);
            DrawText("Q: inspect queen", panelX + 22, TOP + 212, 17, INK);
            DrawText("Tab: cycle objects", panelX + 22, TOP + 237, 17, INK);
        } else {
            DrawText(selected.getName(), panelX + 22, TOP + 70, 23, INK);
            int y = TOP + 110;
            Map<String, String> stats = selected.getStats();
            int rowHeight = Math.min(44, (sceneHeight - 132) / stats.size());
            for (Map.Entry<String, String> stat : stats.entrySet()) {
                DrawText(stat.getKey().toUpperCase(Locale.ROOT), panelX + 22, y, 12, MUTED);
                DrawText(stat.getValue(), panelX + 22, y + 16, 17, INK);
                y += rowHeight;
            }
        }
        DrawRectangle(0, height - BOTTOM, width, BOTTOM, PAPER);
        DrawRectangle(20, height - BOTTOM, width - 40, 1, color(218, 224, 207));
        for (int i = 0; i < Action.values().length; i++) {
            Action action = Action.values()[i];
            Rectangle bounds = buttonBounds(i);
            boolean hovered = CheckCollisionPointRec(GetMousePosition(), bounds);
            boolean active = action == Action.PAUSE && simulation.isPaused()
                    || action == Action.THREATS && simulation.hasAutoThreats();
            DrawRectangleRounded(bounds, 0.2f, 6, hovered || active ? GOLD : INK);
            String label = label(action, simulation);
            int fontSize = MeasureText(label, 16) > bounds.width() - 12 ? 13 : 16;
            int textWidth = MeasureText(label, fontSize);
            DrawText(label, (int) (bounds.x() + (bounds.width() - textWidth) / 2),
                    (int) bounds.y() + 13, fontSize, hovered || active ? INK : PAPER);
        }
        String footer = messageTimer > 0 ? message
                : "Arrows: orbit / zoom    PgUp/PgDn: tilt    Home: camera    G: paths    F12: screenshot    Esc: exit";
        DrawText(footer, 25, height - 30, 15, MUTED);
    }

    private void stat(int x, String label, String value) {
        DrawText(label, x, 20, 13, color(188, 207, 184));
        DrawText(value, x, 43, 26, PAPER);
    }

    private Rectangle buttonBounds(int index) {
        float cell = (GetScreenWidth() - 40) / 8f;
        return rectangle(20 + index * cell, GetScreenHeight() - 88, cell - 8, 42);
    }

    private String label(Action action, Simulation simulation) {
        return switch (action) {
            case WORKER -> "+ Worker [B]";
            case FLOWERS -> "+ Flowers [F]";
            case WASP -> "+ Wasp [W]";
            case VISITOR -> "+ Visitor [E]";
            case PAUSE -> simulation.isPaused() ? "Resume [Space]" : "Pause [Space]";
            case SPEED -> "Speed " + simulation.getSpeed() + "x [X]";
            case THREATS -> "Threats " + (simulation.hasAutoThreats() ? "on" : "off") + " [T]";
            case RESET -> "Reset [R]";
        };
    }

    private static void saveScreenshot(Path path) throws IOException {
        // Raylib's TakeScreenshot prefixes the JVM executable directory in this binding.
        // Exporting a captured image respects the requested absolute path.
        Image frame = LoadImageFromScreen();
        try {
            if (!ExportImage(frame, path.toString())) throw new IOException("Could not save screenshot: " + path);
        } finally {
            UnloadImage(frame);
            frame.close();
        }
    }

    private static Color color(int r, int g, int b) {
        return new Color().r((byte) r).g((byte) g).b((byte) b).a((byte) 255);
    }
    private static Vector3 vector(Vec3 v) {
        return new Vector3().x((float) v.x()).y((float) v.y()).z((float) v.z());
    }
    private static Vec3 coordinates(Vector3 v) { return new Vec3(v.x(), v.y(), v.z()); }
    private static Rectangle rectangle(float x, float y, float w, float h) {
        return new Rectangle().x(x).y(y).width(w).height(h);
    }
}
