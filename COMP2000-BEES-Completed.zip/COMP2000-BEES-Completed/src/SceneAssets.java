import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import static com.raylib.Raylib.*;

/** Loads each GPU resource once and releases it before the window closes. */
public final class SceneAssets implements AutoCloseable {
    private Texture bee;
    private Texture flower;
    private Model tree;

    public SceneAssets() throws IOException {
        for (String asset : new String[]{"Assets/Bee.png", "Assets/flower.png",
                "Assets/beetree.obj", "Assets/beetree.mtl"}) {
            if (!Files.isRegularFile(Path.of(asset))) {
                throw new IOException("Missing " + asset + ". Start the app with run.sh or run.bat from the project.");
            }
        }
        try {
            bee = LoadTexture("Assets/Bee.png");
            flower = LoadTexture("Assets/flower.png");
            tree = LoadModel("Assets/beetree.obj");
            if (!IsTextureValid(bee) || !IsTextureValid(flower) || !IsModelValid(tree)) {
                throw new IOException("The garden textures or model could not be loaded.");
            }
            SetTextureFilter(bee, TEXTURE_FILTER_POINT);
            SetTextureFilter(flower, TEXTURE_FILTER_POINT);
        } catch (IOException | RuntimeException | LinkageError error) {
            close();
            throw error;
        }
    }

    public Texture bee() { return bee; }
    public Texture flower() { return flower; }
    public Model tree() { return tree; }

    public void close() {
        if (tree != null) { UnloadModel(tree); tree.close(); tree = null; }
        if (flower != null) { UnloadTexture(flower); flower.close(); flower = null; }
        if (bee != null) { UnloadTexture(bee); bee.close(); bee = null; }
    }
}
