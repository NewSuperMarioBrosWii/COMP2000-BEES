---
kanban-plugin: board
---

## TODO


## In Progress


## Functional

- [x] Scene Drawing
- [x] Object Picker
- [x] Worker Bee
- [x] Base Bee Class
- [x] Queen Bee / Second Bee Subclass
- [x] Larvae and Hatching
- [x] Flower Generator
- [x] Field and Flower Classes
- [x] Hive and Honey
- [x] Base Enemy Class
- [x] Wasps
- [x] Exterminator
- [x] Generics, Interfaces and Abstract Classes
- [x] Factory and Strategy Patterns
- [x] Exception Handling
- [x] Build / Run Instructions
- [x] Behavioral and Desktop Verification

## Refactor/Rework


%% kanban:settings
```json
{"kanban-plugin":"board","list-collapse":[false,false,false,false]}
```
%%
