#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
./build.sh
case "$(uname -s)" in
    Darwin) exec java -XstartOnFirstThread -cp 'build/classes:lib/jaylib-6.0.1-0.jar' App "$@" ;;
    *) exec java -cp 'build/classes:lib/jaylib-6.0.1-0.jar' App "$@" ;;
esac
