#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
./build.sh
mkdir -p build/test-classes
javac --release 17 -encoding UTF-8 -Xlint:all -Werror -cp build/classes -d build/test-classes tests/SimulationTests.java
java -ea -cp 'build/classes:build/test-classes' SimulationTests
