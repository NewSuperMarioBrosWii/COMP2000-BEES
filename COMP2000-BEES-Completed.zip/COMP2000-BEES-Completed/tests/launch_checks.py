#!/usr/bin/env python3
"""Check launch arguments, headless execution, configuration and missing assets."""
from pathlib import Path
import json
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
checks = []
for name in [".vscode/settings.json", ".vscode/launch.json"]:
    json.loads((ROOT / name).read_text())
    checks.append("PASS valid JSON: " + name)
for arguments in [["--headless", "--seconds", "-1"], ["--headless", "--seconds", "NaN"],
                  ["--invalid", "value"]]:
    result = subprocess.run(["java", "-cp", "build/classes", "App", *arguments],
                            cwd=ROOT, capture_output=True, text=True)
    assert result.returncode == 1 and "Bee Simulator:" in result.stderr, result
    checks.append("PASS invalid arguments rejected: " + " ".join(arguments))
result = subprocess.run(["java", "-cp", "build/classes", "App", "--headless", "--seconds", "300"],
                        cwd=ROOT, capture_output=True, text=True)
assert result.returncode == 0, result.stderr
checks.append("PASS headless without native library on classpath: " + result.stdout.strip())
with tempfile.TemporaryDirectory(prefix="bees-missing-assets-") as temporary:
    classpath = str(ROOT / "build/classes") + ":" + str(ROOT / "lib/jaylib-6.0.1-0.jar")
    result = subprocess.run(["xvfb-run", "-a", "java", "-cp", classpath, "App", "--frames", "1"],
                            cwd=temporary, capture_output=True, text=True, timeout=20)
    output = result.stdout + result.stderr
    assert result.returncode == 1 and "Missing Assets/Bee.png" in output, output
    assert "Window closed successfully" in output, output
    checks.append("PASS missing assets produce a clear error and close the window")
(ROOT / "evidence/launch-checks.txt").write_text("\n".join(checks) + "\n")
print("\n".join(checks))
